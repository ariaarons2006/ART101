
let inhabitors=["Sonic the hedgehog", "Dr. House", "Dr. Wilson"];
let location={
    name: Green-Hill-Zone,
    features: [loop-de-loop, spikes, rings,]  
};

let bigSentence;
bigSentence = "<p>The two humans who exist in the Green Hill Zone are: " + inhabitors[1] + ", " + inhabitors[2] + "</p>";
bigSentence = bigSentence+ "<p>The location" + location.name + "has features such as:" +location.features[0]+ location.features[1]+"and" +location.features[2]+"</p>";

let Sentence;
Sentence= "<p> hi </p>";

$("#output").html(Sentence);

